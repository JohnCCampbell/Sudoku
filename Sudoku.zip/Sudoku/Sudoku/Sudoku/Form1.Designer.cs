﻿namespace Sudoku
{
    partial class sudokuFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loc1Btn = new System.Windows.Forms.Button();
            this.loc2Btn = new System.Windows.Forms.Button();
            this.loc3Btn = new System.Windows.Forms.Button();
            this.loc4Btn = new System.Windows.Forms.Button();
            this.loc5Btn = new System.Windows.Forms.Button();
            this.loc6Btn = new System.Windows.Forms.Button();
            this.loc7Btn = new System.Windows.Forms.Button();
            this.loc8Btn = new System.Windows.Forms.Button();
            this.loc9Btn = new System.Windows.Forms.Button();
            this.loc10Btn = new System.Windows.Forms.Button();
            this.loc11Btn = new System.Windows.Forms.Button();
            this.loc12Btn = new System.Windows.Forms.Button();
            this.loc13Btn = new System.Windows.Forms.Button();
            this.loc14Btn = new System.Windows.Forms.Button();
            this.loc15Btn = new System.Windows.Forms.Button();
            this.loc16Btn = new System.Windows.Forms.Button();
            this.checkBtn = new System.Windows.Forms.Button();
            this.restartBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // loc1Btn
            // 
            this.loc1Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc1Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc1Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc1Btn.Location = new System.Drawing.Point(12, 12);
            this.loc1Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc1Btn.Name = "loc1Btn";
            this.loc1Btn.Size = new System.Drawing.Size(80, 61);
            this.loc1Btn.TabIndex = 0;
            this.loc1Btn.Text = "button1";
            this.loc1Btn.UseVisualStyleBackColor = false;
            this.loc1Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc1Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc2Btn
            // 
            this.loc2Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc2Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc2Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc2Btn.Location = new System.Drawing.Point(90, 12);
            this.loc2Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc2Btn.Name = "loc2Btn";
            this.loc2Btn.Size = new System.Drawing.Size(80, 61);
            this.loc2Btn.TabIndex = 1;
            this.loc2Btn.Text = "button2";
            this.loc2Btn.UseVisualStyleBackColor = false;
            this.loc2Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc2Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc3Btn
            // 
            this.loc3Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc3Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc3Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc3Btn.Location = new System.Drawing.Point(12, 71);
            this.loc3Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc3Btn.Name = "loc3Btn";
            this.loc3Btn.Size = new System.Drawing.Size(80, 61);
            this.loc3Btn.TabIndex = 2;
            this.loc3Btn.Text = "button3";
            this.loc3Btn.UseVisualStyleBackColor = false;
            this.loc3Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc3Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc4Btn
            // 
            this.loc4Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc4Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc4Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc4Btn.Location = new System.Drawing.Point(90, 71);
            this.loc4Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc4Btn.Name = "loc4Btn";
            this.loc4Btn.Size = new System.Drawing.Size(80, 61);
            this.loc4Btn.TabIndex = 3;
            this.loc4Btn.Text = "button4";
            this.loc4Btn.UseVisualStyleBackColor = false;
            this.loc4Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc4Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc5Btn
            // 
            this.loc5Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc5Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc5Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc5Btn.Location = new System.Drawing.Point(170, 12);
            this.loc5Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc5Btn.Name = "loc5Btn";
            this.loc5Btn.Size = new System.Drawing.Size(80, 61);
            this.loc5Btn.TabIndex = 4;
            this.loc5Btn.Text = "button5";
            this.loc5Btn.UseVisualStyleBackColor = false;
            this.loc5Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc5Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc6Btn
            // 
            this.loc6Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc6Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc6Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc6Btn.Location = new System.Drawing.Point(250, 12);
            this.loc6Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc6Btn.Name = "loc6Btn";
            this.loc6Btn.Size = new System.Drawing.Size(80, 61);
            this.loc6Btn.TabIndex = 5;
            this.loc6Btn.Text = "button6";
            this.loc6Btn.UseVisualStyleBackColor = false;
            this.loc6Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc6Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc7Btn
            // 
            this.loc7Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc7Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc7Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc7Btn.Location = new System.Drawing.Point(170, 71);
            this.loc7Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc7Btn.Name = "loc7Btn";
            this.loc7Btn.Size = new System.Drawing.Size(80, 61);
            this.loc7Btn.TabIndex = 6;
            this.loc7Btn.Text = "button7";
            this.loc7Btn.UseVisualStyleBackColor = false;
            this.loc7Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc7Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc8Btn
            // 
            this.loc8Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc8Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc8Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc8Btn.Location = new System.Drawing.Point(250, 71);
            this.loc8Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc8Btn.Name = "loc8Btn";
            this.loc8Btn.Size = new System.Drawing.Size(80, 61);
            this.loc8Btn.TabIndex = 7;
            this.loc8Btn.Text = "button8";
            this.loc8Btn.UseVisualStyleBackColor = false;
            this.loc8Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc8Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc9Btn
            // 
            this.loc9Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc9Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc9Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc9Btn.Location = new System.Drawing.Point(12, 132);
            this.loc9Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc9Btn.Name = "loc9Btn";
            this.loc9Btn.Size = new System.Drawing.Size(80, 61);
            this.loc9Btn.TabIndex = 8;
            this.loc9Btn.Text = "button9";
            this.loc9Btn.UseVisualStyleBackColor = false;
            this.loc9Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc9Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc10Btn
            // 
            this.loc10Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc10Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc10Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc10Btn.Location = new System.Drawing.Point(90, 132);
            this.loc10Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc10Btn.Name = "loc10Btn";
            this.loc10Btn.Size = new System.Drawing.Size(80, 61);
            this.loc10Btn.TabIndex = 9;
            this.loc10Btn.Text = "button10";
            this.loc10Btn.UseVisualStyleBackColor = false;
            this.loc10Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc10Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc11Btn
            // 
            this.loc11Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc11Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc11Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc11Btn.Location = new System.Drawing.Point(12, 191);
            this.loc11Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc11Btn.Name = "loc11Btn";
            this.loc11Btn.Size = new System.Drawing.Size(80, 61);
            this.loc11Btn.TabIndex = 10;
            this.loc11Btn.Text = "button11";
            this.loc11Btn.UseVisualStyleBackColor = false;
            this.loc11Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc11Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc12Btn
            // 
            this.loc12Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc12Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc12Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc12Btn.Location = new System.Drawing.Point(90, 191);
            this.loc12Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc12Btn.Name = "loc12Btn";
            this.loc12Btn.Size = new System.Drawing.Size(80, 61);
            this.loc12Btn.TabIndex = 11;
            this.loc12Btn.Text = "button12";
            this.loc12Btn.UseVisualStyleBackColor = false;
            this.loc12Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc12Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc13Btn
            // 
            this.loc13Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc13Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc13Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc13Btn.Location = new System.Drawing.Point(170, 132);
            this.loc13Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc13Btn.Name = "loc13Btn";
            this.loc13Btn.Size = new System.Drawing.Size(80, 61);
            this.loc13Btn.TabIndex = 12;
            this.loc13Btn.Text = "button13";
            this.loc13Btn.UseVisualStyleBackColor = false;
            this.loc13Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc13Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc14Btn
            // 
            this.loc14Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc14Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc14Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc14Btn.Location = new System.Drawing.Point(250, 132);
            this.loc14Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc14Btn.Name = "loc14Btn";
            this.loc14Btn.Size = new System.Drawing.Size(80, 61);
            this.loc14Btn.TabIndex = 13;
            this.loc14Btn.Text = "button14";
            this.loc14Btn.UseVisualStyleBackColor = false;
            this.loc14Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc14Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc15Btn
            // 
            this.loc15Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc15Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc15Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc15Btn.Location = new System.Drawing.Point(170, 191);
            this.loc15Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc15Btn.Name = "loc15Btn";
            this.loc15Btn.Size = new System.Drawing.Size(80, 61);
            this.loc15Btn.TabIndex = 14;
            this.loc15Btn.Text = "button15";
            this.loc15Btn.UseVisualStyleBackColor = false;
            this.loc15Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc15Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // loc16Btn
            // 
            this.loc16Btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.loc16Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loc16Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loc16Btn.Location = new System.Drawing.Point(250, 191);
            this.loc16Btn.Margin = new System.Windows.Forms.Padding(0);
            this.loc16Btn.Name = "loc16Btn";
            this.loc16Btn.Size = new System.Drawing.Size(80, 61);
            this.loc16Btn.TabIndex = 15;
            this.loc16Btn.Text = "button16";
            this.loc16Btn.UseVisualStyleBackColor = false;
            this.loc16Btn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button_keyPress);
            this.loc16Btn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CellMouseClick);
            // 
            // checkBtn
            // 
            this.checkBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBtn.Location = new System.Drawing.Point(12, 264);
            this.checkBtn.Name = "checkBtn";
            this.checkBtn.Size = new System.Drawing.Size(127, 23);
            this.checkBtn.TabIndex = 16;
            this.checkBtn.Text = "Check Solution ??";
            this.checkBtn.UseVisualStyleBackColor = true;
            this.checkBtn.Click += new System.EventHandler(this.checkBtn_Click);
            // 
            // restartBtn
            // 
            this.restartBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restartBtn.Location = new System.Drawing.Point(176, 264);
            this.restartBtn.Name = "restartBtn";
            this.restartBtn.Size = new System.Drawing.Size(75, 23);
            this.restartBtn.TabIndex = 17;
            this.restartBtn.Text = "Restart";
            this.restartBtn.UseVisualStyleBackColor = true;
            this.restartBtn.Click += new System.EventHandler(this.restartBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBtn.Location = new System.Drawing.Point(257, 264);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(75, 23);
            this.exitBtn.TabIndex = 18;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // sudokuFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(344, 300);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.restartBtn);
            this.Controls.Add(this.checkBtn);
            this.Controls.Add(this.loc16Btn);
            this.Controls.Add(this.loc15Btn);
            this.Controls.Add(this.loc14Btn);
            this.Controls.Add(this.loc13Btn);
            this.Controls.Add(this.loc12Btn);
            this.Controls.Add(this.loc11Btn);
            this.Controls.Add(this.loc10Btn);
            this.Controls.Add(this.loc9Btn);
            this.Controls.Add(this.loc8Btn);
            this.Controls.Add(this.loc7Btn);
            this.Controls.Add(this.loc6Btn);
            this.Controls.Add(this.loc5Btn);
            this.Controls.Add(this.loc4Btn);
            this.Controls.Add(this.loc3Btn);
            this.Controls.Add(this.loc2Btn);
            this.Controls.Add(this.loc1Btn);
            this.Name = "sudokuFrm";
            this.Text = "Sudoku 4X4";
            this.Load += new System.EventHandler(this.sudokuFrm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button loc1Btn;
        private System.Windows.Forms.Button loc2Btn;
        private System.Windows.Forms.Button loc3Btn;
        private System.Windows.Forms.Button loc4Btn;
        private System.Windows.Forms.Button loc5Btn;
        private System.Windows.Forms.Button loc6Btn;
        private System.Windows.Forms.Button loc7Btn;
        private System.Windows.Forms.Button loc8Btn;
        private System.Windows.Forms.Button loc9Btn;
        private System.Windows.Forms.Button loc10Btn;
        private System.Windows.Forms.Button loc11Btn;
        private System.Windows.Forms.Button loc12Btn;
        private System.Windows.Forms.Button loc13Btn;
        private System.Windows.Forms.Button loc14Btn;
        private System.Windows.Forms.Button loc15Btn;
        private System.Windows.Forms.Button loc16Btn;
        private System.Windows.Forms.Button checkBtn;
        private System.Windows.Forms.Button restartBtn;
        private System.Windows.Forms.Button exitBtn;
    }
}

